This is a DEMO file for the neoCRM landing page.
Replace public/downloads/neocrm-demo.zip with the real neoCRM file.
